from setuptools import setup

setup (name="my_new_code",
version="0.1",
description="this is a package",
long_description="this is a very very long description",
author = "Sir Qasim and Syed Muhammad Mooazam",
packages = ["my_new_code"],
install_packages = []
)