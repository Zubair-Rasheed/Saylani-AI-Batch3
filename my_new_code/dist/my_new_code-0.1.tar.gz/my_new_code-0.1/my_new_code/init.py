def funt():
    print("Hello world")
funt()